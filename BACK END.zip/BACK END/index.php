<?php 
include("header.php");
include("navigation.php");
include("footer.php");

 ?>
<!DOCTYPE html>
  <html> 
    <head>
      <!–– meta tag ––>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">

      <!–– css link ––>
      <link rel="stylesheet" type="text/css" href="assets\css\css.css">
    </head>
<body>