<?php 

 ?>        
          <!three bar menu>
          <header> 
              <div class="menu">
              <div class="bar"></div>
              <div class="bar"></div>
              <div class="bar"></div>
  
              <div class="menu-content">
              <a href="#">HOME</a>
              <a href="#">VLOGS</a>
              <a href="#">ABOUT</a>
              <a href="#">CONTACT</a>
              </div>
              </div>
          
              <!libero logo>
              <div class="logo">
              <a href="#"><img src="assets\images\13.jpg"></a>
            </div>
        
            <!Navigation Bar>
            <nav>   
                <a href="#" >HOME</a></li>
                <a href="#" >VLOGS</a></li>
                <a href="#" >ABOUT</a></li>
                <a href="#" >CONTACT</a></li>
              </nav>
                  <!–– Search Icon ––>
                  <div class="SearchBox">
                  <div id="magnifying-glass">
                  <input id="field" type="text" value="Search here"/>    
                  </div>   
                  </div>
              
            
          </header>
